@echo off
cd /d "%~dp0"
title One-Click BAT to EXE Compiler (With Custom Icon)
color 0B

echo ============================================================================
echo              BUILDING STANDALONE EXE WITH CUSTOM ICON ^& UAC SHIELD
echo ============================================================================
echo.

:: 1. Check for Win_Portable_Tools.bat
if not exist "Win_Portable_Tools.bat" (
    echo [ERROR] Could not find 'Win_Portable_Tools.bat' in this folder!
    echo         Make sure your script is named Win_Portable_Tools.bat.
    pause
    exit /b
)

:: 2. Convert logo.png to app.ico automatically if app.ico is missing
if not exist "app.ico" (
    if exist "logo.png" (
        echo Converting logo.png to app.ico...
        powershell -NoProfile -Command "Add-Type -AssemblyName System.Drawing; $b=[System.Drawing.Bitmap]::FromFile('logo.png'); $h=$b.GetHicon(); $i=[System.Drawing.Icon]::FromHandle($h); $fs=New-Object IO.FileStream('app.ico','Create'); $i.Save($fs); $fs.Close()"
    ) else (
        echo [ERROR] No 'app.ico' or 'logo.png' found in this folder!
        echo         Put your icon file in this folder and name it app.ico.
        pause
        exit /b
    )
)

:: 3. Generate C# Wrapper (Program.cs)
echo Creating C# executable wrapper...
> "Program.cs" (
    echo using System;
    echo using System.Diagnostics;
    echo using System.IO;
    echo using System.Reflection;
    echo class Program {
    echo     static void Main^(^) {
    echo         string tempBat = Path.Combine^(Path.GetTempPath^(^), "Win_Portable_Tools_" + Guid.NewGuid^(^).ToString^("N"^) + ".bat"^);
    echo         using ^(Stream s = Assembly.GetExecutingAssembly^(^).GetManifestResourceStream^("Win_Portable_Tools.bat"^)^)
    echo         using ^(FileStream fs = new FileStream^(tempBat, FileMode.Create^)^) { s.CopyTo^(fs^); }
    echo         ProcessStartInfo psi = new ProcessStartInfo^("cmd.exe", "/c \"" + tempBat + "\""^) { UseShellExecute = true, Verb = "runas" };
    echo         try { Process p = Process.Start^(psi^); p.WaitForExit^(^); }
    echo         finally { if ^(File.Exists^(tempBat^)^) File.Delete^(tempBat^); }
    echo     }
    echo }
)

:: 4. Compile into Win_Portable_Tools.exe using built-in Windows .NET compiler
echo Compiling Win_Portable_Tools.exe...
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /nologo /target:exe /out:Win_Portable_Tools.exe /win32icon:app.ico /resource:Win_Portable_Tools.bat Program.cs

:: 5. Clean up temporary Program.cs file
del /f /q "Program.cs" >nul 2>&1

echo.
if exist "Win_Portable_Tools.exe" (
    echo [SUCCESS] 'Win_Portable_Tools.exe' created with your custom icon!
) else (
    echo [ERROR] Compilation failed. Make sure app.ico is a valid .ico icon file.
)
pause
