@echo off
:: Auto-elevate to Administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Detect PC Model, CPU, RAM, Free Disk Space, and Uptime
echo Scanning hardware and system health...
for /f "delims=" %%I in ('powershell -NoProfile -Command "(Get-CimInstance Win32_ComputerSystem).Model"') do set "SYS_MODEL=%%I"
for /f "delims=" %%I in ('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor).Name"') do set "SYS_CPU=%%I"
for /f "delims=" %%I in ('powershell -NoProfile -Command "[math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)"') do set "SYS_RAM=%%I GB"
for /f "delims=" %%I in ('powershell -NoProfile -Command "[math]::Round((Get-PSDrive C).Free / 1GB, 1)"') do set "SYS_FREE=%%I"
for /f "delims=" %%I in ('powershell -NoProfile -Command "[math]::Round(((Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime).TotalDays, 1)"') do set "SYS_UP=%%I"

:menu
cls
title Window 10/11 portable tools
color 0B
echo ============================================================================
echo                         WINDOW 10/11 PORTABLE TOOLS
echo                        Should hopefully work -martin ng
echo ============================================================================
echo  Model : %SYS_MODEL%  ^|  RAM: %SYS_RAM%  ^|  C: Free: %SYS_FREE% GB
echo  CPU   : %SYS_CPU%  ^|  Uptime: %SYS_UP% Days
echo ----------------------------------------------------------------------------
powershell -NoProfile -Command "if([double]'%SYS_FREE%' -lt 15){Write-Host '  [!] WARNING: Low C: Drive space (<15 GB). Run Option 10 Cleanup!' -ForegroundColor Yellow}; if([double]'%SYS_UP%' -gt 7){Write-Host '  [!] TIP: PC has been running >7 days. Restart soon to clear memory.' -ForegroundColor Yellow}"
echo ============================================================================
echo  TABS  : [M] Main Tweaks (Current)   [E] Repair ^& Mobile Kit   [T] Test Menu
echo ============================================================================
echo  [SAFETY]
echo   1. Create System Restore Point (Run First)
echo.
echo  [APPEARANCE ^& WALLPAPER]
echo   2. Set Custom Login Wallpaper (.jpg/.png)    3. Reset Login Wallpaper
echo   4. Enable Classic Win10 Context Menu         5. Restore Win11 Context Menu
echo   6. Toggle Dark Mode ON                       7. Toggle Light Mode ON
echo.
echo  [GAMING ^& PERFORMANCE]
echo   8. Enable Gaming Tweaks (No Accel/GameDVR)   9. Unlock Ultimate Performance
echo  10. Deep Disk ^& Temp Cleanup + Flush DNS     11. Smart Battery Optimiser
echo.
echo  [PRIVACY, DEBLOAT, AUDIO ^& BOOT]
echo  12. Disable Telemetry ^& Background Apps      13. Custom Bloatware Remover Menu
echo  14. Install Custom Shutdown Sound (.wav)     15. Explorer ^& Search Speed Pack
echo  16. Remove Desktop Startup Delay             17. Verbose Boot/Shutdown Messages
echo  18. Repair Windows Files (DISM + SFC)        19. Update All Apps (Winget)
echo  20. REVERT ALL TWEAKS TO DEFAULT (Keeps SFC/DISM Repairs ^& Cleanups)
echo.
echo   0. Exit
echo ============================================================================
set /p choice=Select (0-20), [E] Repair Kit, or [T] Test Menu: 

if /i "%choice%"=="E" goto repair_menu
if /i "%choice%"=="T" goto test_menu
if "%choice%"=="1" goto restore
if "%choice%"=="2" goto set_login_wall
if "%choice%"=="3" goto reset_login_wall
if "%choice%"=="4" goto classic_menu
if "%choice%"=="5" goto win11_menu
if "%choice%"=="6" goto dark_mode
if "%choice%"=="7" goto light_mode
if "%choice%"=="8" goto gaming
if "%choice%"=="9" goto power_plan
if "%choice%"=="10" goto cleanup
if "%choice%"=="11" goto battery
if "%choice%"=="12" goto privacy
if "%choice%"=="13" goto debloat_menu
if "%choice%"=="14" goto shutdown_sound
if "%choice%"=="15" goto qol_pack
if "%choice%"=="16" goto boot_delay
if "%choice%"=="17" goto boot_verbose
if "%choice%"=="18" goto repair
if "%choice%"=="19" goto winget_up
if "%choice%"=="20" goto revert_all
if "%choice%"=="0" exit
goto menu

:: ============================================================================
:: SUB-MENU: CUSTOM BLOATWARE REMOVER & RESTORER (OPTION 13)
:: ============================================================================
:debloat_menu
cls
title Window 10/11 portable tools - [Bloatware Manager]
color 0D
echo ============================================================================
echo                    SELECT BLOATWARE TO REMOVE OR RESTORE
echo ============================================================================
echo   1. Disable Windows Copilot               (2 = Restore Copilot)
echo   3. Disable Taskbar Widgets ^& News Feed   (4 = Restore Widgets)
echo   5. Uninstall OneDrive                    (6 = Reinstall OneDrive via Winget)
echo   7. Remove Preinstalled Xbox / Game Apps  (Game Bar, Xbox App, Companion)
echo   8. Remove Preinstalled Microsoft Bloat   (Clipchamp, Solitaire, Bing News/Weather)
echo   9. REMOVE ALL BLOATWARE ABOVE AT ONCE
echo.
echo   M. Back to Main Menu                     0. Exit
echo ============================================================================
set /p bchoice=Select Bloatware Option (1-9) or [M] Back: 

if /i "%bchoice%"=="M" goto menu
if "%bchoice%"=="0" exit
if "%bchoice%"=="1" (
    reg add "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f >nul
    taskkill /f /im explorer.exe >nul & start explorer.exe
    echo Windows Copilot disabled!
    pause
    goto debloat_menu
)
if "%bchoice%"=="2" (
    reg delete "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /f >nul 2>&1
    taskkill /f /im explorer.exe >nul & start explorer.exe
    echo Windows Copilot restored!
    pause
    goto debloat_menu
)
if "%bchoice%"=="3" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f >nul
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 2 /f >nul
    taskkill /f /im explorer.exe >nul & start explorer.exe
    echo Taskbar Widgets ^& News Feed disabled!
    pause
    goto debloat_menu
)
if "%bchoice%"=="4" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 1 /f >nul
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 0 /f >nul
    taskkill /f /im explorer.exe >nul & start explorer.exe
    echo Taskbar Widgets ^& News Feed restored!
    pause
    goto debloat_menu
)
if "%bchoice%"=="5" (
    echo Uninstalling Microsoft OneDrive...
    taskkill /f /im OneDrive.exe >nul 2>&1
    if exist "%SystemRoot%\System32\OneDriveSetup.exe" "%SystemRoot%\System32\OneDriveSetup.exe" /uninstall
    if exist "%SystemRoot%\SysWOW64\OneDriveSetup.exe" "%SystemRoot%\SysWOW64\OneDriveSetup.exe" /uninstall
    echo OneDrive uninstalled!
    pause
    goto debloat_menu
)
if "%bchoice%"=="6" (
    echo Reinstalling Microsoft OneDrive...
    winget install -e --id Microsoft.OneDrive --accept-package-agreements --accept-source-agreements
    pause
    goto debloat_menu
)
if "%bchoice%"=="7" (
    echo Removing Xbox / Game Bar bloatware apps...
    powershell -NoProfile -Command "Get-AppxPackage *XboxApp* | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxPackage *XboxGamingOverlay* | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxPackage *XboxIdentityProvider* | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxPackage *XboxSpeechToTextOverlay* | Remove-AppxPackage -ErrorAction SilentlyContinue"
    echo Xbox bloatware removed!
    pause
    goto debloat_menu
)
if "%bchoice%"=="8" (
    echo Removing Clipchamp, Solitaire, Bing News, and Bing Weather...
    powershell -NoProfile -Command "Get-AppxPackage *Clipchamp* | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxPackage *MicrosoftSolitaireCollection* | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxPackage *BingNews* | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxPackage *BingWeather* | Remove-AppxPackage -ErrorAction SilentlyContinue"
    echo Preinstalled consumer bloatware removed!
    pause
    goto debloat_menu
)
if "%bchoice%"=="9" (
    echo Removing all selected bloatware...
    reg add "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f >nul
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f >nul
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 2 /f >nul
    taskkill /f /im OneDrive.exe >nul 2>&1
    if exist "%SystemRoot%\System32\OneDriveSetup.exe" "%SystemRoot%\System32\OneDriveSetup.exe" /uninstall
    if exist "%SystemRoot%\SysWOW64\OneDriveSetup.exe" "%SystemRoot%\SysWOW64\OneDriveSetup.exe" /uninstall
    powershell -NoProfile -Command "Get-AppxPackage *XboxApp*,*XboxGamingOverlay*,*Clipchamp*,*MicrosoftSolitaireCollection*,*BingNews*,*BingWeather* | Remove-AppxPackage -ErrorAction SilentlyContinue"
    taskkill /f /im explorer.exe >nul & start explorer.exe
    echo All bloatware removed!
    pause
    goto debloat_menu
)
goto debloat_menu

:: ============================================================================
:: PAGE 2: HARDWARE REPAIR, DRIVERS, USB CREATOR & LEGACY MOBILE TOOLS
:: ============================================================================
:repair_menu
cls
title Window 10/11 portable tools - [Repair Kit]
color 0A
echo ============================================================================
echo               HARDWARE REPAIR, DRIVERS, USB ^& MOBILE TOOLKIT
echo ============================================================================
echo  TABS  : [M] Main Tweaks   [E] Repair ^& Mobile Kit (Current)   [T] Test Menu
echo ============================================================================
echo  [BOOTABLE USB ^& FIRMWARE]
echo   1. Bootable USB Creator (ISO ^& DD Raw Image Writer)
echo   2. Patch Windows 11 USB (Bypass TPM, SecureBoot ^& RAM Checks)
echo   3. Reboot Directly into Motherboard BIOS / UEFI
echo.
echo  [DRIVERS, ANDROID ^& LEGACY iOS REPAIR]
echo   4. Backup All PC Drivers to C:\DriverBackup (Before Reinstall)
echo   5. Block Windows Update from Overwriting Drivers (6 = Allow Again)
echo   7. Install Android ADB ^& Fastboot Tools (Winget)
echo   8. Install Apple Device Drivers ^& libimobiledevice (iOS Repair)
echo   9. Open Official Legacy iOS Kit Guide (GitHub - LukeZGD)
echo.
echo  [NETWORK, LICENSE ^& DIAGNOSTICS]
echo  10. Network Reset + Cloudflare DNS (1.1.1.1)
echo  11. Show Saved Wi-Fi Passwords ^& IP Info
echo  12. Check SSD / Hard Drive SMART Health
echo  13. Save Battery Health ^& System Audit Reports (Desktop)
echo  14. Backup BitLocker Recovery Key
echo  15. Install Essential IT Apps (7-Zip, VLC, Notepad++, Git)
echo  16. Show Windows Product Key (BIOS OEM ^& Registry License Key)
echo.
echo   M. Back to Main Tweaks       0. Exit
echo ============================================================================
set /p rchoice=Select (1-16), [M] Main Menu, or [T] Test Menu:
if /i "%rchoice%"=="M" goto menu
if /i "%rchoice%"=="T" goto test_menu
if "%rchoice%"=="0" exit
if "%rchoice%"=="1" goto usb_maker
if "%rchoice%"=="2" goto tpm_bypass
if "%rchoice%"=="3" goto bios_reboot
if "%rchoice%"=="4" goto backup_drivers
if "%rchoice%"=="5" goto block_wu_drivers
if "%rchoice%"=="6" goto allow_wu_drivers
if "%rchoice%"=="7" goto adb_install
if "%rchoice%"=="8" goto ios_tools
if "%rchoice%"=="9" goto legacy_ios_web
if "%rchoice%"=="10" goto net_fix
if "%rchoice%"=="11" goto wifi_info
if "%rchoice%"=="12" goto disk_health
if "%rchoice%"=="13" goto reports
if "%rchoice%"=="14" goto bitlocker_keys
if "%rchoice%"=="15" goto install_apps
if "%rchoice%"=="16" goto win_key
goto repair_menu
:: ============================================================================
:: PAGE 3: LIVE TEST MENU
:: ============================================================================
:test_menu
cls
title Window 10/11 portable tools - [Test Menu]
color 0E
echo ============================================================================
echo                         LIVE TWEAK TEST ^& STATUS CHECKER
echo ============================================================================
echo  TABS  : [M] Main Tweaks   [E] Repair ^& Mobile Kit   [T] Test Menu (Current)
echo ============================================================================
echo   1. Test Custom Shutdown Sound (Play Now)
echo   2. Preview Login Wallpaper (Locks Screen via Win+L)
echo   3. Open Windows Sound Events (Verify Native Sound Scheme)
echo   4. Open Windows Update ^& Optional Driver Updates
echo   5. Live Tweak Status Check
echo.
echo   M. Back to Main Tweaks       E. Repair Kit       0. Exit
echo ============================================================================
set /p tchoice=Select (1-5), [M] Main Menu, or [E] Repair Kit:
if /i "%tchoice%"=="M" goto menu
if /i "%tchoice%"=="E" goto repair_menu
if "%tchoice%"=="0" exit
if "%tchoice%"=="1" goto test_shut
if "%tchoice%"=="2" goto test_lock
if "%tchoice%"=="3" goto test_snd_ui
if "%tchoice%"=="4" goto test_wu_ui
if "%tchoice%"=="5" goto test_stat
goto test_menu
:test_shut
if exist "C:\ProgramData\CustomSounds\shutdown.wav" (
echo Playing shutdown sound...
powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\ProgramData\CustomSounds\shutdown.wav').PlaySync()"
) else (
echo No shutdown sound set! Use Option 14 on Main Menu first.
)
pause
goto test_menu
:test_lock
rundll32.exe user32.dll,LockWorkStation
goto test_menu
:test_snd_ui
control mmsys.cpl sounds
goto test_menu
:test_wu_ui
start ms-settings:windowsupdate-optionalupdates
goto test_menu
:test_stat
cls
echo ============================================================================
echo                           CURRENT TWEAK STATUS
echo ============================================================================
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP" /v LockScreenImagePath >nul 2>&1 && echo [ACTIVE]  Custom Login Wallpaper || echo [DEFAULT] Login Wallpaper
if exist "C:\ProgramData\CustomSounds\shutdown.wav" (echo [ACTIVE]  Custom Shutdown / Logoff Sound) else (echo [NONE]    Custom Shutdown Sound)
reg query "HKCU\Control Panel\Mouse" /v MouseSpeed 2>nul | find "0" >nul && echo [ACTIVE]  Gaming Mouse Boost || echo [DEFAULT] Mouse Acceleration
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry 2>nul | find "0x0" >nul && echo [ACTIVE]  Privacy Shield || echo [DEFAULT] Telemetry Enabled
reg query "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot 2>nul | find "0x1" >nul && echo [ACTIVE]  Copilot Disabled || echo [DEFAULT] Copilot Enabled
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v HideFileExt 2>nul | find "0x0" >nul && echo [ACTIVE]  File Extensions Shown || echo [DEFAULT] File Extensions Hidden
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec 2>nul | find "0x0" >nul && echo [ACTIVE]  Startup Delay Removed || echo [DEFAULT] Standard Startup Delay
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v VerboseStatus 2>nul | find "0x1" >nul && echo [ACTIVE]  Verbose Boot/Shutdown Status || echo [DEFAULT] Standard Boot Screen
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate 2>nul | find "0x1" >nul && echo [ACTIVE]  Windows Update Driver Overwrite Blocked || echo [DEFAULT] Automatic Driver Updates Allowed
echo ============================================================================
pause
goto test_menu
:: ============================================================================
:: PAGE 1 FUNCTIONS
:: ============================================================================
:restore
echo.
echo Creating System Restore Point...
powershell -NoProfile -Command "Enable-ComputerRestore -Drive 'C:'; Checkpoint-Computer -Description 'Win11Tweaker_Backup' -RestorePointType 'MODIFY_SETTINGS'"
echo Done!
pause
goto menu
:set_login_wall
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.OpenFileDialog; if($f.ShowDialog() -eq 'OK'){$f.FileName}"') do set "imgfile=%%I"
if "%imgfile%"=="" goto menu
if not exist "C:\Windows\Web\CustomWall" mkdir "C:\Windows\Web\CustomWall"
copy /y "%imgfile%" "C:\Windows\Web\CustomWall\lockscreen.jpg" >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP" /v LockScreenImagePath /t REG_SZ /d "C:\Windows\Web\CustomWall\lockscreen.jpg" /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP" /v LockScreenImageUrl /t REG_SZ /d "C:\Windows\Web\CustomWall\lockscreen.jpg" /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP" /v LockScreenImageStatus /t REG_DWORD /d 1 /f >nul
echo.
echo Login / Lock Screen wallpaper updated! Press Win + L to test it.
pause
goto menu
:reset_login_wall
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP" /f >nul 2>&1
rmdir /s /q "C:\Windows\Web\CustomWall" >nul 2>&1
echo.
echo Login wallpaper reset to Windows default!
pause
goto menu
:classic_menu
reg add "HKCU\Software\Classes\CLSID{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" /f /ve >nul
taskkill /f /im explorer.exe >nul & start explorer.exe
echo Classic Context Menu enabled!
pause
goto menu
:win11_menu
reg delete "HKCU\Software\Classes\CLSID{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /f >nul 2>&1
taskkill /f /im explorer.exe >nul & start explorer.exe
echo Default Windows 11 Context Menu restored!
pause
goto menu
:dark_mode
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AppsUseLightTheme /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v SystemUsesLightTheme /t REG_DWORD /d 0 /f >nul
taskkill /f /im explorer.exe >nul & start explorer.exe
echo Dark Mode enabled!
pause
goto menu
:light_mode
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AppsUseLightTheme /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v SystemUsesLightTheme /t REG_DWORD /d 1 /f >nul
taskkill /f /im explorer.exe >nul & start explorer.exe
echo Light Mode enabled!
pause
goto menu
:gaming
echo.
echo Applying Gaming Optimisations...
reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d "0" /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d "0" /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d "0" /f >nul
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v AllowGameDVR /t REG_DWORD /d 0 /f >nul
echo Gaming tweaks applied! (Sign out/in for mouse curve changes to take effect).
pause
goto menu
:power_plan
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 >nul
echo Ultimate Performance plan unlocked! Open Power Options to select it.
pause
goto menu
:cleanup
echo.
echo Cleaning temp files, Windows Update cache, and flushing DNS...
del /s /f /q "%temp%*." >nul 2>&1
del /s /f /q "C:\Windows\Temp*." >nul 2>&1
net stop wuauserv >nul 2>&1
del /s /f /q "C:\Windows\SoftwareDistribution\Download*.*" >nul 2>&1
net start wuauserv >nul 2>&1
ipconfig /flushdns >nul
echo Temp files, update cache cleared, and DNS flushed!
pause
goto menu
:battery
echo.
echo Applying Smart Battery Optimisations...
powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e >nul 2>&1
powercfg /setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 70 >nul 2>&1
powercfg /setdcvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 2 >nul 2>&1
powercfg /setdcvalueindex SCHEME_CURRENT SUB_ENERGYSAVER ESBATTTHRESHOLD 30 >nul 2>&1
powercfg /change monitor-timeout-dc 3 >nul 2>&1
powercfg /change standby-timeout-dc 10 >nul 2>&1
powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100 >nul 2>&1
powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0 >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f >nul
powercfg /setactive SCHEME_CURRENT >nul 2>&1
echo Smart Battery Optimiser applied! (Full speed on charger, power saving on battery).
pause
goto menu
:privacy
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v Enabled /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f >nul
echo Privacy and background app tweaks applied!
pause
goto menu
:shutdown_sound
echo.
echo Select a standard PCM .WAV file for Shutdown / Logoff...
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.OpenFileDialog; if($f.ShowDialog() -eq 'OK'){$f.FileName}"') do set "wavfile=%%I"
if "%wavfile%"=="" goto menu
if not exist "C:\ProgramData\CustomSounds" mkdir "C:\ProgramData\CustomSounds"
copy /y "%wavfile%" "C:\ProgramData\CustomSounds\shutdown.wav" >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 0 /f >nul
reg delete "HKCU\AppEvents\EventLabels\WindowsLogoff" /v ExcludeFromCPL /f >nul 2>&1
reg delete "HKCU\AppEvents\EventLabels\SystemExit" /v ExcludeFromCPL /f >nul 2>&1
reg add "HKCU\AppEvents\Schemes\Apps.Default\WindowsLogoff.Current" /ve /t REG_SZ /d "C:\ProgramData\CustomSounds\shutdown.wav" /f >nul
reg add "HKCU\AppEvents\Schemes\Apps.Default\WindowsLogoff.Modified" /ve /t REG_SZ /d "C:\ProgramData\CustomSounds\shutdown.wav" /f >nul
reg add "HKCU\AppEvents\Schemes\Apps.Default\SystemExit.Current" /ve /t REG_SZ /d "C:\ProgramData\CustomSounds\shutdown.wav" /f >nul
reg add "HKCU\AppEvents\Schemes\Apps.Default\SystemExit.Modified" /ve /t REG_SZ /d "C:\ProgramData\CustomSounds\shutdown.wav" /f >nul
echo Custom Shutdown / Logoff sound installed!
pause
goto menu
:qol_pack
echo.
echo Applying Explorer ^& Search Quality-of-Life Tweaks...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v HideFileExt /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Policies\Microsoft\Windows\Explorer" /v DisableSearchBoxSuggestions /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v DisallowShaking /t REG_DWORD /d 1 /f >nul
taskkill /f /im explorer.exe >nul & start explorer.exe
echo File extensions enabled, Bing Start Search disabled, and Aero Shake turned off!
pause
goto menu
:boot_delay
echo.
echo  1. Remove Desktop Startup Delay (Faster App Loading)
echo  2. Restore Default Startup Delay
set /p dchoice=Select (1 or 2):
if "%dchoice%"=="1" (
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec /t REG_DWORD /d 0 /f >nul
echo Desktop startup delay removed!
)
if "%dchoice%"=="2" (
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /f >nul 2>&1
echo Default Windows startup delay restored!
)
pause
goto menu
:boot_verbose
echo.
echo  1. Enable Verbose Boot/Shutdown Messages (Show Detailed Driver/Service Status)
echo  2. Restore Standard Windows Boot/Shutdown Screen
set /p vchoice=Select (1 or 2):
if "%vchoice%"=="1" (
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v VerboseStatus /t REG_DWORD /d 1 /f >nul
echo Verbose boot/shutdown status enabled!
)
if "%vchoice%"=="2" (
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v VerboseStatus /f >nul 2>&1
echo Standard boot/shutdown screen restored!
)
pause
goto menu
:repair
echo.
echo Running DISM Image Repair and System File Checker...
DISM /Online /Cleanup-Image /RestoreHealth
sfc /scannow
echo System integrity scan complete!
pause
goto menu
:winget_up
echo.
echo Updating all apps via Winget...
winget upgrade --all --include-unknown --accept-package-agreements --accept-source-agreements
echo Done!
pause
goto menu
:revert_all
echo.
set /p revconf=Type YES to revert all tweaks to Windows defaults (keeps repairs/cleanups):
if not "%revconf%"=="YES" goto menu
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP" /f >nul 2>&1
rmdir /s /q "C:\Windows\Web\CustomWall" >nul 2>&1
reg delete "HKCU\Software\Classes\CLSID{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /f >nul 2>&1
reg add "HKCU\AppEvents\Schemes\Apps.Default\WindowsLogoff.Current" /ve /t REG_SZ /d "" /f >nul
reg add "HKCU\AppEvents\Schemes\Apps.Default\SystemExit.Current" /ve /t REG_SZ /d "" /f >nul
rmdir /s /q "C:\ProgramData\CustomSounds" >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d "1" /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d "6" /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d "10" /f >nul
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 1 /f >nul
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /f >nul 2>&1
powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e >nul 2>&1
powercfg /restoredefaultschemes >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v Enabled /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 0 /f >nul
reg delete "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds" /v ShellFeedsTaskbarViewMode /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v HideFileExt /t REG_DWORD /d 1 /f >nul
reg delete "HKCU\Software\Policies\Microsoft\Windows\Explorer" /v DisableSearchBoxSuggestions /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v VerboseStatus /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /f >nul 2>&1
taskkill /f /im explorer.exe >nul & start explorer.exe
echo All tweaks reverted to Windows defaults!
pause
goto menu
:: ============================================================================
:: PAGE 2 FUNCTIONS (REPAIR, DRIVERS & MOBILE)
:: ============================================================================
:usb_maker
cls
color 0C
echo ============================================================================
echo              BOOTABLE USB CREATOR (ISO ^& DD RAW IMAGE WRITER)
echo ============================================================================
echo  [!] WARNING: All files on the selected USB drive will be WIPED.
echo  [!] Minimum Recommended USB Size: 8 GB (Windows) / 4 GB (Linux)
echo ============================================================================
for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.OpenFileDialog; if($f.ShowDialog() -eq 'OK'){$f.FileName}"') do set "isofile=%%I"
if "%isofile%"=="" goto repair_menu
for /f "delims=" %%I in ('powershell -NoProfile -Command "[math]::Round((Get-Item '%isofile%').Length / 1GB, 2)"') do set "isosize=%%I"
echo Selected File : %isofile%
echo Image Size    : %isosize% GB
echo.
powershell -NoProfile -Command "$u = Get-Disk | Where-Object {$.BusType -eq 'USB'}; if(-not $u){Write-Host '[!] NO USB DRIVES DETECTED!' -ForegroundColor Yellow} else {$u | Select-Object Number, FriendlyName, @{Name='Size(GB)';Expression={[math]::Round($.Size/1GB,2)}}, PartitionStyle | Format-Table -AutoSize}"
set /p disknum=Enter USB Disk Number to flash (or B to cancel):
if /i "%disknum%"=="B" goto repair_menu
for /f "delims=" %%I in ('powershell -NoProfile -Command "$d = Get-Disk -Number %disknum% -ErrorAction SilentlyContinue; if(-not $d -or $d.BusType -ne 'USB'){'INVALID'} elseif(($d.Size / 1GB) -lt %isosize%){'TOOSMALL'} else {'OK'}"') do set "usbcheck=%%I"
if "%usbcheck%"=="INVALID" (echo [ERROR] Not a valid USB drive! & pause & goto repair_menu)
if "%usbcheck%"=="TOOSMALL" (echo [ERROR] USB is smaller than %isosize% GB! & pause & goto repair_menu)
echo.
echo  1. Standard ISO Mode (UEFI Bootable - Windows 10/11)
echo  2. DD Raw Image Mode (Byte-for-Byte - Linux / Recovery ISOs)
set /p wmode=Choose Write Mode (1 or 2):
set /p confirm=Type YES in capitals to erase Disk %disknum% and flash:
if not "%confirm%"=="YES" goto repair_menu
if "%wmode%"=="1" (
powershell -NoProfile -Command "Clear-Disk -Number %disknum% -RemoveData -RemoveOEM -Confirm:$false; Initialize-Disk -Number %disknum% -PartitionStyle GPT; $iso = Mount-DiskImage -ImagePath '%isofile%' -PassThru; $isoDrive = ($iso | Get-Volume).DriveLetter + ':'; $wim = Get-ChildItem -Path ($isoDrive + '\sources\install.*') -ErrorAction SilentlyContinue | Where-Object {$_.Length -gt 4GB}; $fs = if($wim){'NTFS'}else{'FAT32'}; $part = New-Partition -DiskNumber %disknum% -UseMaximumSize -AssignDriveLetter; Format-Volume -Partition $part -FileSystem $fs -NewFileSystemLabel 'BOOT_USB' -Confirm:$false | Out-Null; Copy-Item -Path ($isoDrive + '*') -Destination ($part.DriveLetter + ':') -Recurse -Force; Dismount-DiskImage -ImagePath '%isofile%' | Out-Null; Write-Host 'SUCCESS! Bootable USB created.' -ForegroundColor Green"
pause
goto repair_menu
)
if "%wmode%"=="2" (
powershell -NoProfile -Command "Clear-Disk -Number %disknum% -RemoveData -RemoveOEM -Confirm:$false -ErrorAction SilentlyContinue; Set-Disk -Number %disknum% -IsOffline $true; $in = [System.IO.File]::OpenRead('%isofile%'); $out = New-Object System.IO.FileStream(('\.\PhysicalDrive' + %disknum%), [System.IO.FileMode]::Open, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None); $buf = New-Object byte[] 1048576; while(($read = $in.Read($buf, 0, $buf.Length)) -gt 0){$out.Write($buf, 0, $read)}; $out.Flush(); $out.Close(); $in.Close(); Set-Disk -Number %disknum% -IsOffline $false; Write-Host 'SUCCESS! DD Image written.' -ForegroundColor Green"
pause
goto repair_menu
)
goto repair_menu
:tpm_bypass
echo.
set /p usbdrv=Enter Drive Letter of your Windows 11 USB (e.g. D):
if not exist "%usbdrv%:\sources\install.wim" if not exist "%usbdrv%:\sources\install.esd" (
echo [!] No Windows installer found on %usbdrv%:\sources.
pause
goto repair_menu
)
mkdir "C:\WinPE_Mount" >nul 2>&1
dism /Mount-Wim /WimFile:"%usbdrv%:\sources\boot.wim" /Index:2 /MountDir:"C:\WinPE_Mount"
reg load HKLM\OFFLINE_SYSTEM "C:\WinPE_Mount\Windows\System32\config\SYSTEM"
reg add "HKLM\OFFLINE_SYSTEM\Setup\LabConfig" /v BypassTPMCheck /t REG_DWORD /d 1 /f
reg add "HKLM\OFFLINE_SYSTEM\Setup\LabConfig" /v BypassSecureBootCheck /t REG_DWORD /d 1 /f
reg add "HKLM\OFFLINE_SYSTEM\Setup\LabConfig" /v BypassRAMCheck /t REG_DWORD /d 1 /f
reg unload HKLM\OFFLINE_SYSTEM
dism /Unmount-Wim /MountDir:"C:\WinPE_Mount" /Commit
rmdir /s /q "C:\WinPE_Mount" >nul 2>&1
echo Success! Windows 11 hardware checks bypassed on USB %usbdrv%:.
pause
goto repair_menu
:bios_reboot
set /p bconf=Type YES to restart straight into BIOS/UEFI:
if /i "%bconf%"=="YES" shutdown /r /fw /t 0
goto repair_menu
:backup_drivers
echo.
echo Exporting all installed third-party drivers to C:\DriverBackup...
if not exist "C:\DriverBackup" mkdir "C:\DriverBackup"
pnputil /export-driver * "C:\DriverBackup"
echo All drivers backed up to C:\DriverBackup!
pause
goto repair_menu
:block_wu_drivers
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /t REG_DWORD /d 1 /f >nul
echo Windows Update is now blocked from overwriting your custom drivers!
pause
goto repair_menu
:allow_wu_drivers
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /f >nul 2>&1
echo Automatic Windows Update driver updates restored!
pause
goto repair_menu
:adb_install
winget install -e --id Google.PlatformTools --accept-package-agreements --accept-source-agreements
pause
goto repair_menu
:ios_tools
winget install -e --id Apple.iTunes --accept-package-agreements --accept-source-agreements
winget install -e --id libimobiledevice.libimobiledevice --accept-package-agreements --accept-source-agreements
pause
goto repair_menu
:legacy_ios_web
start github.com
goto repair_menu
:net_fix
ipconfig /release >nul 2>&1 & ipconfig /flushdns >nul & ipconfig /renew >nul 2>&1 & netsh winsock reset >nul
powershell -NoProfile -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Set-DnsClientServerAddress -ServerAddresses ('1.1.1.1','1.0.0.1')" >nul 2>&1
echo Network reset and Cloudflare 1.1.1.1 DNS applied!
pause
goto repair_menu
:wifi_info
cls
ipconfig | findstr /i "IPv4 Subnet Default"
echo.
powershell -NoProfile -Command "(netsh wlan show profiles) | Select-String ':(.+)$' | ForEach-Object { $name=$_.Matches.Groups.Value.Trim(); $pass=(netsh wlan show profile name="$name" key=clear | Select-String 'Key Content\W+:(.+)$'); if($pass){$p=$pass.Matches.Groups.Value.Trim()}else{$p='[Open / Enterprise]'}; Write-Output "$name : $p" }"
pause
goto repair_menu
:disk_health
cls
powershell -NoProfile -Command "Get-PhysicalDisk | Select-Object DeviceId, FriendlyName, MediaType, HealthStatus, OperationalStatus, @{Name='Size(GB)';Expression={[math]::Round($_.Size/1GB,1)}} | Format-Table -AutoSize"
pause
goto repair_menu
:reports
powercfg /batteryreport /output "%USERPROFILE%\Desktop\Battery_Report.html" >nul 2>&1
systeminfo > "%USERPROFILE%\Desktop\System_Audit.txt"
echo Saved Battery_Report.html and System_Audit.txt to Desktop!
pause
goto repair_menu
:bitlocker_keys
cls
manage-bde -protectors -get C:
pause
goto repair_menu
:install_apps
winget install -e --id 7zip.7zip --accept-package-agreements --accept-source-agreements
winget install -e --id VideoLAN.VLC --accept-package-agreements --accept-source-agreements
winget install -e --id Notepad++.Notepad++ --accept-package-agreements --accept-source-agreements
winget install -e --id Git.Git --accept-package-agreements --accept-source-agreements
pause
goto repair_menu
:win_key
cls
echo ============================================================================
echo                     WINDOWS PRODUCT KEY ^& LICENSE INFO
echo ============================================================================
echo [BIOS / UEFI OEM KEY (Embedded in Motherboard)]
powershell -NoProfile -Command "$k = (Get-CimInstance -Query 'select * from SoftwareLicensingService').OA3xOriginalProductKey; if($k){Write-Host '  OEM Key : ' $k -ForegroundColor Green} else {Write-Host '  OEM Key : None detected (Digital License / Retail)' -ForegroundColor Yellow}"
echo.
echo [ACTIVE REGISTRY LICENSE KEY]
powershell -NoProfile -Command "$map='BCDFGHJKMPQRTVWXY2346789'; $val=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').DigitalProductId; if($val){$isWin8=[math]::Floor($val[66]/6) -band 1; $val[66]=($val[66] -band 247) -bor (($isWin8 -band 2)4); $key=''; for($i=24;$i -ge 0;$i--){$cur=0; for($j=14;$j -ge 0;$j--){$cur=$cur256 -bxor $val[$j+52]; $val[$j+52]=[math]::Floor($cur/24); $cur=$cur%%24}; $key=$map[$cur]+$key; $last=$cur}; if($isWin8 -eq 1){$key=$key.Substring(1,$last)+'N'+$key.Substring($last+1)}; $fmt=($key -replace '(.{5})(?!$)','$1-'); Write-Host '  Reg Key : ' $fmt -ForegroundColor Cyan}"
echo.
echo [ACTIVATION STATUS]
cscript //nologo C:\Windows\System32\slmgr.vbs /xpr
echo ============================================================================
pause
goto repair_menu